# Starter Builds — Android wrapper

A minimal WebView app that loads the Starter Builds 3D previewer
(https://claude.ai/artifact/EtP6WzdZvLBwR4hoU12BZ2) as a full-screen
native app, so it installs like a normal APK instead of a browser tab.

## Why you're getting this as a zip, not a finished APK

Bitrise builds from a git repository — it has no way to accept files
directly, and your Bitrise account doesn't have a repo connected yet.
I can't create or host a repo for you (no GitHub/GitLab connection
available here), so this last step needs you.

## Get it building on Bitrise (~5 minutes)

1. Create an empty repo (e.g. on GitHub) and push this whole folder to it.
2. Tell me the repo URL — I'll register it on your Bitrise workspace and
   trigger the first build myself using the `bitrise.yml` already included
   here (it builds a debug APK from the `app` module).
3. Once it finishes, the APK is downloadable from that build's Artifacts
   tab in Bitrise (I can also pull the link for you if you ask).

If you'd rather do it yourself: on Bitrise, Add app → paste the repo URL
→ it'll detect `bitrise.yml` automatically → Start build.

## If you just want it on your phone right now

You don't need an APK for that — open the previewer link above in your
phone's browser and use "Add to Home screen." Same app, one less step.
