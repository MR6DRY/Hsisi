package com.starterbuilds.app

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

// Minimal WebView wrapper: loads the live 3D build previewer.
// Swap PREVIEWER_URL for your own host if you move the page later.
class MainActivity : AppCompatActivity() {
    companion object {
        private const val PREVIEWER_URL = "https://claude.ai/artifact/EtP6WzdZvLBwR4hoU12BZ2"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        setContentView(webView)
        webView.loadUrl(PREVIEWER_URL)
    }
}
